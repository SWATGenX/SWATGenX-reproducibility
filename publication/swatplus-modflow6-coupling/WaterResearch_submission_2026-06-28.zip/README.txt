WATER RESEARCH SUBMISSION PACKAGE
Watershed-scale PFAS fate and transport across surface water and groundwater:
a two-way coupled SWAT+/MODFLOW 6 model
Assembled 2026-06-28

CONTENTS
  manuscript.pdf                 main manuscript (line-numbered, double-spaced)
  supplementary_material.pdf     supplementary information
  cover_letter.pdf               cover letter to the Editor
  graphical_abstract.pdf         graphical abstract (vector)
  graphical_abstract_300dpi.png  graphical abstract (>=300 dpi)
  highlights.txt                 highlights (<=85 chars each)
  figures_main/                  main figures, each as its own file (printed order)
  figures_SI/                    supplementary figures (printed order)
  latex_source/                  full buildable LaTeX project (tex + bib + bbl + figures)

MAIN FIGURE ORDER (matches the manuscript)
  Figure  1  conceptual
  Figure  2  study
  Figure  3  instream
  Figure  4  soil
  Figure  5  swpfas
  Figure  6  gwpfas
  Figure  7  finger
  Figure  8  joint
  Figure  9  uncertainty
  Figure 10  gridcompare

SUPPLEMENTARY FIGURE ORDER
  Figure S1   si_soil_partition.png
  Figure S2   si_instream_profile.png
  Figure S3   si_perreach_residual.png
  Figure S4   si_network_longitudinal.png
  Figure S5   fig5_calibration_uncertainty.pdf
  Figure S6   fig6_param_sensitivity.pdf
  Figure S7   si_watertable_map.png
  Figure S8   si_head_calibration.png
  Figure S9   si_pilotpoints_map.png
  Figure S10  si_plume_map.png
  Figure S11  si_gw_validation.png
  Figure S12  si_sft_network.png
  Figure S13  si_joint_diagnostics.png
  Figure S14  joint_calibration.png
  Figure S15  oat_tornado.png
  Figure S16  si_morris

REMAINING -- AUTHOR DECISIONS BEFORE SUBMITTING
  1. Length: trim main text if desired (WR asks for conciseness, no hard cap).
  2. Verify the "~150 m DEM bias" figure in methods-modflow-generation.tex.
  3. (Optional) 3-5 suggested reviewers for Editorial Manager -- not required.
  4. Final read-through.
